﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn
{
    public class SerializeListToJsonWithNewtonsoftJson
    {
        private readonly List<Contacts> _contactList;
        private readonly string _filepath;
        public SerializeListToJsonWithNewtonsoftJson(List<Contacts> contactList,string filepath)
        {
            _contactList = contactList;
            _filepath = filepath;

        }
        private readonly JsonSerializerSettings _settings = new()
        {
            Formatting = Formatting.Indented,
            ContractResolver = new DefaultContractResolver { NamingStrategy = new CamelCaseNamingStrategy() },
        };
        public string SerializeObjectMethod()
        {
            return JsonConvert.SerializeObject(_contactList, _settings);
        }

        public void JsonSerializerClass()
        {
            var serializer = JsonSerializer.Create(_settings);
            var stringBuilder = new StringBuilder();
            using (var writer = new JsonTextWriter(new StringWriter(stringBuilder)))
            {
                serializer.Serialize(writer, _contactList);
            }
            File.WriteAllText( _filepath, stringBuilder.ToString());
        }
    }
}
