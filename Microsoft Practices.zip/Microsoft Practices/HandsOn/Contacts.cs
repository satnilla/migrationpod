﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn
{
    public class Contacts
    {
        public string Name { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string Mobile { get; set; } = string.Empty;

        //List<Contacts> _contacts = new()
        //{
        //    new Contacts
        //    {
        //        Name = "Satish",
        //        Address = "Hyderabad",
        //        Mobile = "9999123456",
        //    },
        //    new Contacts
        //    {
        //        Name = "Ravi",
        //        Address = "Bangalore",
        //        Mobile = "9999123457",
        //    },
        //    new Contacts
        //    {
        //        Name = "Somu",
        //        Address = "Mumbai",
        //        Mobile = "9999123458",
        //    }
        //};
      
    }
    

}
