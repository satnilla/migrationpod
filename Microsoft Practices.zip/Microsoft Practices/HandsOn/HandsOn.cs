﻿using Newtonsoft.Json;
using SProductsApi;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn
{
    public class MigrationPod
    {
        // Finding common elements between the two arrays
        public int[] FindCommonElements(int[] arr1, int[] arr2)
        {
            int[] result = new int[arr1.Length];
            for (int i = 0; i < arr1.Length; i++)
            {
                for (int j = 0; j < arr2.Length; j++)
                {
                    if (arr1[i] == arr2[j])
                    {
                        result[i] = arr1[i];
                    }
                }

            }
            return result;
        }

        // Validate the Parentheses balanced or not
        public bool AreParenthesesBalanced(string parentheses)
        {
            const char LeftParenthesis = '(';
            const char RightParenthesis = ')';
            uint BracketCount = 0;

            try
            {
                checked  // Turns on overflow checking.
                {
                    for (int Index = 0; Index < parentheses.Length; Index++)
                    {
                        switch (parentheses[Index])
                        {
                            case LeftParenthesis:
                                BracketCount++;
                                continue;
                            case RightParenthesis:
                                BracketCount--;
                                continue;
                            default:
                                continue;
                        }  // end of switch()

                    }
                }
            }

            catch (OverflowException)
            {
                return false;
            }

            if (BracketCount == 0)
            {
                return true;
            }

            return false;
        }

        // Serialize the List of Contact to JSON and writing into the file 
        public void SerializeContactsToJson(List<Contacts> contacts, string  filePath)
        {
            SerializeListToJsonWithNewtonsoftJson obj = new SerializeListToJsonWithNewtonsoftJson(contacts, filePath + "jsontotext.txt");
            obj.JsonSerializerClass();
        }
       
        //Take the apiURL and JSON response to List of software products and return
        public async Task<List<SoftwareProducts>>  GetSoftwareProductsAsync(string apiUrl)
        {
            //HttpClient client = new HttpClient();
            //HttpResponseMessage response =  client.GetAsync("https://localhost:7237/api/values/getall");
            //response.EnsureSuccessStatusCode();
            //string responseBody =  response.Content.ReadAsStringAsync();

            apiUrl = "https://localhost:7237/api/values/getall";
            List<SoftwareProducts> products = new List<SoftwareProducts>();
            // Create HttpClient
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    // Send GET request to the API
                    HttpResponseMessage response = await client.GetAsync(apiUrl);

                    // Check if the request was successful
                    if (response.IsSuccessStatusCode)
                    {
                        // Read the content of the response as a JSON string
                        string jsonResult = await response.Content.ReadAsStringAsync();

                        // Deserialize the JSON string into objects
                        // You'll need to have a class that represents the structure of the JSON response
                        // For example, if the response has a structure like {"name": "John", "age": 30}, you'd have a corresponding class
                        // For simplicity, I'll assume the response is an array of strings
                         products = Newtonsoft.Json.JsonConvert.DeserializeObject<List<SoftwareProducts>>(jsonResult);

                    }
                    else
                    {
                        Console.WriteLine($"Error: {response.StatusCode} - {response.ReasonPhrase}");
                    }
                    
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Exception: {ex.Message}");
                }
                return products;
            }


            //List<SoftwareProducts> products = JsonConvert.DeserializeObject<List<SoftwareProducts>>(responseBody);
           
        }
    }
} 
