﻿using HandsOn;
using SProductsApi;

// Call Common elements between the arrays

int[] arr1 = { 12, 5, 45, 47, 22, 10 };
int[] arr2 = { 23, 45, 10, 58, 78, 77, 46 };

MigrationPod obPod = new MigrationPod();
int[] output = obPod.FindCommonElements(arr1, arr2);

// Calling Parenthese balanced method

bool result = obPod.AreParenthesesBalanced("(())");
Console.WriteLine(result);

// Calling  JSON serialization into string and write into the file
List<Contacts> _contacts = new()
{
    new Contacts
    {
        Name = "Satish",
        Address = "Hyderabad",
        Mobile = "9999123456",
    },
    new Contacts
    {
        Name = "Ravi",
        Address = "Bangalore",
        Mobile = "9999123457",
    },
    new Contacts
    {
        Name = "Somu",
        Address = "Mumbai",
        Mobile = "9999123458",
    }
};

SerializeListToJsonWithNewtonsoftJson obj = new SerializeListToJsonWithNewtonsoftJson(_contacts, @"C:\Users\USER\Desktop\" + "jsontotext.txt");
obj.JsonSerializerClass();

// Calling Api End point 

Task<List<SoftwareProducts>> products =  obPod.GetSoftwareProductsAsync("https://localhost:7237/api/values/getall");
Console.ReadLine();
