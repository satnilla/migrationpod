﻿namespace SProductsApi
{
    public class SoftwareProducts
    {
        public string Product { get; set; } = String.Empty;
        public string Version { get; set; } = String.Empty;
    }
}
