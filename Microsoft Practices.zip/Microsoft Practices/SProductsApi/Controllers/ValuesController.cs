﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace SProductsApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        public static List<SoftwareProducts> prodList = new List<SoftwareProducts>()
        {
            new SoftwareProducts { Product = ".NET", Version = "1.0"},
            new SoftwareProducts { Product = "JAVA", Version = "2.0"},
            new SoftwareProducts { Product = "RPA", Version = "3.0"},
        };
        [Route("getall")]
        public ActionResult GetAllItems()
        {
           
            return Ok(JsonConvert.SerializeObject(prodList));
        }
    }
}
